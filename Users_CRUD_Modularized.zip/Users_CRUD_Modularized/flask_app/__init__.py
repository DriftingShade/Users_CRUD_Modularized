from flask import Flask

app = Flask(__name__)
app.secret_key = "2b6b850349c178a919f7998aab2c6730e0384e363ea48dd01e5631a681199a58"
